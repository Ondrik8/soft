#pragma once

// This is cpuz_141.sys embedded as a byte array
// It is dropped to disk when necessary
extern unsigned char CpuzDriverFile[46400];
